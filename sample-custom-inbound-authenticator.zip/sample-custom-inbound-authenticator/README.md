# sample-custom-inbound-authenticator
A sample implementation of a custom inbound authenticator. Compatible with WSO2 Identity Server 5.3.0.

Please see the associated [WSO2 Library Article](https://wso2.com/library/articles/2017/04/writing-a-custom-inbound-authenticator-for-wso2-identity-server/) for usage.
