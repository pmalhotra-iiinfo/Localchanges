package org.wso2.sample.local.authenticator;

/**
 * Constants used by the BasicAuthenticator
 */
public abstract class TTBAuthenticatorConstants {

    public static final String AUTHENTICATOR_NAME = "TTBAuthenticator";
    public static final String AUTHENTICATOR_FRIENDLY_NAME = "TTBAuth";
    public static final String USER_NAME = "username";
    public static final String PASSWORD = "password";

    public static final String ACCEPT_PARAM_KEY = "Accept";
    public static final String CONTENT_TYPE_PARAM_KEY = "Content-Type";
    public static final String PRAGMA_PARAM_KEY = "Pragma";
    public static final String CACHE_CONTROL_PARAM_KEY = "Cache-Control";

    public static final String CONFIG_API_URL = "AuthRESTAPIUrl";
    public static final String DEFAULT_PROFILE = "default";
    public static final String RESULT_KEY = "resultKey";

    private TTBAuthenticatorConstants() {
    }

}
