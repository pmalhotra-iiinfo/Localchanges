package org.wso2.sample.local.authenticator;

import org.apache.http.Header;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.util.EntityUtils;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.List;

public class TTBClient {

    private String cookies = "";
    private final String USER_AGENT = "Mozilla/5.0";

    public String sendPost(final String url, final List<NameValuePair> postParams) throws Exception {

        final HttpClient client = HttpClientBuilder.create().build();

        final HttpPost post = new HttpPost(url);

        post.setHeader("Origin", "https://www.ttbonline.gov");
        post.setHeader("User-Agent", USER_AGENT );
        post.setHeader("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8");
        post.setHeader("Accept-Language", "en-US,en;q=0.5");
        post.setHeader("Cookie", getCookies() );
        post.setHeader("Connection", "keep-alive");
        post.setHeader("Content-Type", "application/x-www-form-urlencoded");
        post.setHeader("Upgrade-Insecure-Requests", "1");
        post.setHeader("Referer", "https://www.ttbonline.gov/permitsonline/Welcome.aspx");
        post.setHeader("Accept-Encoding", "gzip, deflate, br");
        post.setHeader("Cache-Control", "max-age=0");

        post.setEntity(new UrlEncodedFormEntity(postParams));

        final HttpResponse response = client.execute(post);

        final int responseCode = response.getStatusLine().getStatusCode();

        final BufferedReader rd = new BufferedReader(new InputStreamReader(post.getEntity().getContent()));

        final StringBuffer result1 = new StringBuffer();
        String line = "";
        while ((line = rd.readLine()) != null) {
            result1.append(line);
        }

        for (final Header header : post.getAllHeaders()) {

        }

        final String result = EntityUtils.toString(response.getEntity());

        return result;
    }

    public String getCookies() {
        return cookies;
    }

}
