cp target/custom.inbound.authenticator-1.0.0.jar /home/prasadi/DevService/WUM/wso2is-5.8.0/repository/components/dropins 
