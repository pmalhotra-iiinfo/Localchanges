package org.wso2.carbon.identity.application.ttb.authenticator.basicauth;

/**
 * Constants used by the TTBCustomAuthenticator
 */
public abstract class TTBCustomAuthenticatorConstants {

    public static final String AUTHENTICATOR_NAME = "TTBCustomAuthenticator-FONL";
    public static final String AUTHENTICATOR_FRIENDLY_NAME = "TTBAuth-FONL";
    public static final String USER_NAME = "username";
    public static final String PASSWORD = "password";

    public static final String ACCEPT_PARAM_KEY = "Accept";
    public static final String CONTENT_TYPE_PARAM_KEY = "Content-Type";
    public static final String PRAGMA_PARAM_KEY = "Pragma";
    public static final String CACHE_CONTROL_PARAM_KEY = "Cache-Control";

    public static final String CONFIG_API_URL = "AuthRESTAPIUrl";
    public static final String DEFAULT_PROFILE = "default";

    private TTBCustomAuthenticatorConstants() {
    }
}
